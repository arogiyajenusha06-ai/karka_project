import rateLimit from 'express-rate-limit';

// Rate limiter: 30 requests per minute per IP address
export const chatRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30, // max 30 chat requests per minute
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  message: {
    success: false,
    error: 'Rate limit exceeded. Please wait a moment before sending another message to NEXA.',
  },
});
