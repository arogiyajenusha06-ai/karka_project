import { Router } from 'express';
import { handleChatMessage, handleHealthCheck } from '../controllers/chatController.js';
import { chatRateLimiter } from '../middleware/rateLimiter.js';

const router = Router();

// Health check endpoint
router.get('/health', handleHealthCheck);

// Chatbot query endpoint with rate limiting
router.post('/chat', chatRateLimiter, handleChatMessage);

export default router;
