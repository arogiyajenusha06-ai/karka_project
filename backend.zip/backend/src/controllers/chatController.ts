import { Request, Response } from 'express';
import { getAiReply, ChatMessage } from '../services/aiService.js';

export async function handleChatMessage(req: Request, res: Response): Promise<void> {
  try {
    const { message, history } = req.body;

    // 1. Validation
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      res.status(400).json({
        success: false,
        error: 'Invalid message. Message must be a non-empty string.',
      });
      return;
    }

    if (message.length > 2000) {
      res.status(400).json({
        success: false,
        error: 'Message is too long. Please limit to 2000 characters.',
      });
      return;
    }

    // Sanitize and validate conversation history if provided
    let cleanHistory: ChatMessage[] = [];
    if (Array.isArray(history)) {
      cleanHistory = history
        .filter((h) => h && (h.role === 'user' || h.role === 'assistant') && typeof h.content === 'string')
        .slice(-10) // Keep at most the last 10 messages
        .map((h) => ({
          role: h.role,
          content: h.content.slice(0, 2000),
        }));
    }

    // 2. Process with AI service
    const reply = await getAiReply(message.trim(), cleanHistory);

    res.status(200).json({
      success: true,
      data: reply,
    });
  } catch (error: any) {
    console.error('[NEXA Controller Error]:', error);
    res.status(500).json({
      success: false,
      error: 'An internal server error occurred while processing your request.',
    });
  }
}

export function handleHealthCheck(_req: Request, res: Response): void {
  const apiKeyConfigured = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
  res.status(200).json({
    status: 'online',
    service: 'Karka NEXUS API & NEXA Guide',
    timestamp: new Date().toISOString(),
    aiEngine: {
      mode: apiKeyConfigured ? 'live-configured' : 'deterministic-demo',
      provider: apiKeyConfigured ? 'Google Gemini 1.5' : 'Karka Deterministic Knowledge Engine',
    },
  });
}
