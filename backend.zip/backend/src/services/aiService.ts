import { NEXA_SYSTEM_PROMPT } from '../config/systemPrompt.js';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface NexaResponse {
  text: string;
  mode: 'live' | 'demo';
  timestamp: string;
  suggestedQuestions?: string[];
}

/**
 * Intelligent deterministic response generator when no live API key is configured or fallback occurs.
 * Covers all official Karka Academy & GenAI Mastery domains with conversational nuance.
 */
function generateDeterministicReply(userQuery: string, history: ChatMessage[] = []): string {
  const q = userQuery.toLowerCase().trim();

  // 1. Course overview / GenAI Mastery
  if (
    q.includes('genai mastery') ||
    q.includes('course') ||
    q.includes('syllabus') ||
    q.includes('curriculum') ||
    q.includes('what will i learn') ||
    q.includes('duration') ||
    q.includes('lesson')
  ) {
    return (
      `**Generative AI Mastery at Karka Academy** is our flagship 6-month intensive program featuring **48 comprehensive lessons**.\n\n` +
      `The curriculum is divided into three enterprise-grade pillars:\n` +
      `• **Module 1: Advanced LLMs** — Fine-Tuning Techniques, Parameter-Efficient Fine-Tuning (PEFT), and Rigorous Model Evaluation.\n` +
      `• **Module 2: Custom AI Solutions** — Autonomous AI Agents, Function Calling, Tool Use, and Multi-Modal Integration.\n` +
      `• **Module 3: Enterprise AI** — Scaling AI Workloads, Data Privacy in GenAI, and Inference Cost Optimization.\n\n` +
      `Training is delivered in a **blended format** (online and hands-on offline in Nagercoil) with real industry projects and verified certification. Would you like to know about the admission process or Pay After Placement?`
    );
  }

  // 2. Pay After Placement / Fees
  if (
    q.includes('pay after placement') ||
    q.includes('fee') ||
    q.includes('cost') ||
    q.includes('price') ||
    q.includes('free') ||
    q.includes('upfront')
  ) {
    return (
      `**Zero Upfront Fees: The Pay After Placement Model**\n\n` +
      `At Karka Academy, we believe financial constraints should never stand between human curiosity and technology mastery:\n\n` +
      `• **Learn First:** Enroll, attend lectures, build enterprise projects, and complete internships with zero upfront tuition fees.\n` +
      `• **Pay Only When Hired:** You begin paying back the program tuition only after you secure an eligible job in the tech industry.\n` +
      `• **Shared Alignment:** We invest directly in your career success from Day One.\n\n` +
      `For specific enrollment agreements and batch eligibility, contact our admissions desk at **+91 9487530243** or visit [karka.academy](https://www.karka.academy/).`
    );
  }

  // 3. Coding prerequisites / Beginner friendliness
  if (
    q.includes('coding') ||
    q.includes('experience') ||
    q.includes('beginner') ||
    q.includes('prerequisite') ||
    q.includes('eligibility') ||
    q.includes('non-tech')
  ) {
    return (
      `**Prerequisites & Eligibility for GenAI Mastery:**\n\n` +
      `• **Who can apply:** College students, fresh graduates, working professionals, and curious developers.\n` +
      `• **Coding background:** While basic familiarity with programming logic (especially Python fundamentals) is helpful during the technical interview, our mentors guide you from foundational principles into advanced orchestration.\n` +
      `• **Mindset:** What matters most is intellectual curiosity and a drive to build real solutions rather than just copy-paste prompts.\n\n` +
      `We conduct a friendly **Technical Interview** to assess your baseline and craft the best learning path for you.`
    );
  }

  // 4. Projects & Hands-on Work
  if (
    q.includes('project') ||
    q.includes('build') ||
    q.includes('portfolio') ||
    q.includes('agency') ||
    q.includes('real world')
  ) {
    return (
      `**What Projects Will You Build in GenAI Mastery?**\n\n` +
      `Rather than toy demo apps, students build production-ready systems:\n` +
      `1. **Enterprise RAG Knowledge Assistant:** Custom vector search pipeline querying company internal documentation with zero hallucination.\n` +
      `2. **Multi-Agent Workflow Orchestrator:** Autonomous agents collaborating to analyze data, execute code, and trigger API webhooks.\n` +
      `3. **Generative Content Studio:** Automated multi-modal production engine generating brand-aligned visual and written copy at scale.\n\n` +
      `Plus, every learner undertakes a **guaranteed industry internship** delivering real client-facing software!`
    );
  }

  // 5. How to Enroll / Admissions
  if (
    q.includes('enroll') ||
    q.includes('apply') ||
    q.includes('join') ||
    q.includes('register') ||
    q.includes('admission')
  ) {
    return (
      `**3-Step Admission Process for Karka GenAI Mastery:**\n\n` +
      `1. **Application:** Submit your basic details and interest via our website or campus admissions desk.\n` +
      `2. **Technical Interview:** A constructive 1-on-1 discussion on Python fundamentals, problem-solving, and your AI aspirations.\n` +
      `3. **Enrollment & Onboarding:** Secure your seat in the upcoming cohort and gain instant access to preparatory resources.\n\n` +
      `Ready to take the leap? Click the **"Enroll in GenAI Mastery"** button or call **+91 9487530243** directly.`
    );
  }

  // 6. Placement & Career Support / Hiring Partners
  if (
    q.includes('placement') ||
    q.includes('job') ||
    q.includes('career') ||
    q.includes('hiring') ||
    q.includes('company') ||
    q.includes('salary') ||
    q.includes('companies')
  ) {
    return (
      `**Karka Career & Placement Ecosystem:**\n\n` +
      `• **95% Placement Track Record:** Consistent placement success across technical cohorts.\n` +
      `• **Dedicated Placement Cell:** Personalized 1-on-1 mentoring, unlimited mock technical interviews, and ATS resume refinement.\n` +
      `• **Guaranteed Internship:** Graduate with verified work experience on actual agency deliverables.\n` +
      `• **Hiring Partners:** Our graduates are making an impact at companies like **Amazon, TCS, HCL, Matrimony.com, Novac, Capecom, Flow, Sodisys**, and emerging AI startups.`
    );
  }

  // 7. Platforms: Spike AI & Infini
  if (q.includes('spike') || q.includes('infini') || q.includes('platform') || q.includes('competition')) {
    return (
      `**The Karka Technology Platforms:**\n\n` +
      `• **Spike AI (spike.karka.academy):** Our custom AI-powered interactive learning platform. Ask Spike anything you are studying, receive step-by-step code guidance, track progress, and learn paired with expert mentors.\n` +
      `• **Karka Infini AI (infini.karka.academy):** Inter-college technology arena with a ₹1,00,000 prize pool and rolling trophy. Features contests in PaperPulse (Idea Presentation), TechRush (Technical Quiz), Bug Hunt (Debugging), SiteSprint (Web Dev), Graphix (Design), and VibeCut (Video).`
    );
  }

  // 8. Location & Contact
  if (q.includes('location') || q.includes('address') || q.includes('where') || q.includes('nagercoil') || q.includes('contact') || q.includes('phone')) {
    return (
      `**Karka AI & Tech Academy Campus:**\n\n` +
      `• **Headquarters:** Nagercoil, Kanyakumari District, Tamil Nadu (India).\n` +
      `• **Phone:** +91 9487530243\n` +
      `• **Email:** contact@karka.academy\n` +
      `• **Hours:** Monday – Saturday, 09:00 AM – 06:00 PM IST.\n` +
      `• **Modes:** We offer both in-person offline instruction at Nagercoil and flexible online hybrid options!`
    );
  }

  // 9. Greeting / General
  if (q.includes('hello') || q.includes('hi') || q.includes('hey') || q.includes('who are you')) {
    return (
      `Hello! I'm **NEXA**, your dedicated AI guide at Karka Academy.\n\n` +
      `I'm here to help you explore our **Generative AI Mastery** course, understand our **Pay After Placement** model, view curriculum details, or find out what projects you will build. What area are you most curious about today?`
    );
  }

  // Default intelligent contextual response
  return (
    `Thank you for asking! At **Karka NEXUS**, we focus on transforming raw human curiosity into tangible AI mastery.\n\n` +
    `Whether you want to explore the **6-month GenAI Mastery program (48 lessons)**, understand how our **Zero Upfront Fee (Pay After Placement)** structure works, or discover the autonomous agent projects our students build, I'm here to guide you.\n\n` +
    `Feel free to ask:\n` +
    `• *"What is the curriculum for GenAI Mastery?"*\n` +
    `• *"How does Pay After Placement work?"*\n` +
    `• *"Do I need prior coding experience?"*\n` +
    `• *"What companies hire Karka graduates?"*`
  );
}

/**
 * Main chat handler: tries live LLM (Gemini) if API key is supplied,
 * otherwise seamlessly falls back to high-fidelity deterministic simulator.
 */
export async function getAiReply(message: string, history: ChatMessage[] = []): Promise<NexaResponse> {
  const apiKey = process.env.GEMINI_API_KEY || process.env.AI_API_KEY;
  const timestamp = new Date().toISOString();

  // If no API key is provided, execute deterministic knowledge mode
  if (!apiKey || apiKey.trim() === '' || apiKey === 'YOUR_GEMINI_API_KEY') {
    const text = generateDeterministicReply(message, history);
    return {
      text,
      mode: 'demo',
      timestamp,
      suggestedQuestions: [
        'Explore GenAI Mastery curriculum',
        'How does Pay After Placement work?',
        'Do I need coding experience?',
        'What projects will I build?',
      ],
    };
  }

  // Attempt live LLM generation with Gemini REST API
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000); // 12s timeout

    // Build conversation contents for Gemini
    const contents: any[] = [];

    // Add prior conversation history (limited to last 6 messages to preserve context and speed)
    const recentHistory = history.slice(-6);
    for (const h of recentHistory) {
      contents.push({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: h.content }],
      });
    }

    // Add current user message
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{ text: NEXA_SYSTEM_PROMPT }],
        },
        contents,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 600,
        },
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      console.warn(`[NEXA] Gemini API responded with status ${response.status}. Falling back to deterministic mode.`);
      const text = generateDeterministicReply(message, history);
      return {
        text,
        mode: 'demo',
        timestamp,
      };
    }

    const data = await response.json();
    const replyText = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!replyText) {
      const text = generateDeterministicReply(message, history);
      return { text, mode: 'demo', timestamp };
    }

    return {
      text: replyText,
      mode: 'live',
      timestamp,
      suggestedQuestions: [
        'Tell me more about the curriculum',
        'How do I apply for the next cohort?',
        'What real-world projects are included?',
      ],
    };
  } catch (err: any) {
    console.warn(`[NEXA] Live AI request failed (${err?.message}). Using intelligent deterministic fallback.`);
    const text = generateDeterministicReply(message, history);
    return {
      text,
      mode: 'demo',
      timestamp,
    };
  }
}
